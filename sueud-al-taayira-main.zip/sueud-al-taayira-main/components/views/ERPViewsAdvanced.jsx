'use client';

import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

const styles = { 
  input: { width: '100%', padding: '12px 15px', margin: '6px 0', border: '1px solid #E2E8F0', borderRadius: '8px', outline: 'none', boxSizing: 'border-box', fontSize: '14px' }, 
  btnPrimary: { padding: '12px 15px', background: 'linear-gradient(135deg, #1E3A8A, #2563EB)', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', boxShadow: '0 4px 6px rgba(37, 99, 235, 0.3)' }, 
  btnSuccess: { padding: '8px 12px', background: '#059669', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '500' }, 
  btnWarning: { padding: '8px 12px', background: '#FBBF24', color: '#1E293B', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '600' }, 
  btnInfo: { padding: '8px 12px', background: '#2563EB', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '500' }, 
  card: { background: 'white', padding: '25px', borderRadius: '16px', boxShadow: '0 4px 6px rgba(0,0,0,0.05)', marginBottom: '20px', border: '1px solid #e2e8f0' }, 
  label: { fontSize: '13px', fontWeight: '600', color: '#475569', marginBottom: '6px', display: 'block', marginTop: '12px' },
  tableHeader: { background: '#1E293B', color: 'white', padding: '15px', textAlign: 'start', fontSize: '13px' },
  tableCell: { padding: '15px', borderBottom: '1px solid #F1F5F9', fontSize: '14px' }
};

export default function ERPViewsAdvanced(props) {
  const { page, data, tr, today, userProfile, showToast, setData, handlePaySalary, handleGenerateSlip } = props;
  
  // FIX: Moved all useState hooks to the top level to prevent React Hooks violation
  const [editTargetId, setEditTargetId] = useState(null);
  const [targetVal, setTargetVal] = useState(0);
  const [attForm, setAttForm] = useState({ empId: '', date: today, checkIn: '09:00', checkOut: '18:00', status: 'Present', leaveStart: today, leaveEnd: today });
  const [attendance, setAttendance] = useState([]);
  const [payForm, setPayForm] = useState({ empId: '', base: 0, comm: 0, adv_ded: 0, gift: 0, month: today.substring(0, 7), mode: 'Cash' });
  const [quoteForm, setQuoteForm] = useState({ customer_name: '', service_type: 'Flight Ticket', price: '', valid_until: today });

  // Fetch Attendance History
  useEffect(() => {
    if (page === 'hr_advanced' && userProfile?.tenant_id) {
      supabase.from('attendance').select('*, employees(name)').eq('tenant_id', userProfile.tenant_id).order('date', { ascending: false }).then(({ data: att }) => {
        setAttendance(att || []);
      });
    }
  }, [page, userProfile]);

  const saveTarget = async (empId) => {
    try {
      const { data: upEmp, error } = await supabase.from('employees').update({ target: parseFloat(targetVal) || 0 }).eq('id', empId).select().single();
      if (error) throw error;
      setData(prev => ({ ...prev, employees: prev.employees.map(e => e.id === empId ? upEmp : e) }));
      showToast(tr.save || 'Target Updated!');
      setEditTargetId(null);
    } catch (err) { showToast('Error: ' + err.message); }
  };

  const calcAttendance = (checkIn, checkOut) => {
    const [inH, inM] = checkIn.split(':').map(Number);
    const [outH, outM] = checkOut.split(':').map(Number);
    let totalMins = (outH * 60 + outM) - (inH * 60 + inM);
    if (totalMins < 0) totalMins += 24 * 60; // Overnight shift
    const workedHrs = totalMins / 60;
    
    let ot = 0, deduction = 0;
    if (workedHrs > 9) ot = workedHrs - 9; // Overtime after 9 hours
    if (workedHrs < 8 && workedHrs >= 0) deduction = 8 - workedHrs; // Deduction if less than 8 hours
    
    return { ot: ot.toFixed(1), deduction: deduction.toFixed(1) };
  };

  const markAttendance = async (e) => {
    e.preventDefault();
    if (!attForm.empId) return showToast(tr.selectEmployee || 'Please select an employee');
    try {
      let payload = {
        employee_id: attForm.empId, 
        date: attForm.date, 
        status: attForm.status,
        tenant_id: userProfile.tenant_id
      };

      if (attForm.status === 'Present') {
        const { ot, deduction } = calcAttendance(attForm.checkIn, attForm.checkOut);
        payload.check_in = attForm.checkIn;
        payload.check_out = attForm.checkOut;
        payload.overtime = parseFloat(ot);
        payload.deduction = parseFloat(deduction);
      } else if (attForm.status === 'Leave') {
        payload.leave_start = attForm.leaveStart;
        payload.leave_end = attForm.leaveEnd;
        payload.check_in = null;
        payload.check_out = null;
      }

      const { data: newAtt, error } = await supabase.from('attendance').insert([payload]).select('*, employees(name)').single();
      if (error) throw error;
      
      setAttendance(prev => [newAtt, ...prev]);
      
      let msg = `${tr.mark || 'Attendance Marked'}!`;
      if (payload.overtime > 0) msg += ` ${tr.overtime || 'OT'}: ${payload.overtime} hrs.`;
      if (payload.deduction > 0) msg += ` ${tr.deduction || 'Deduction'}: ${payload.deduction} hrs.`;
      showToast(msg);
      
      setAttForm({ empId: '', date: today, checkIn: '09:00', checkOut: '18:00', status: 'Present', leaveStart: today, leaveEnd: today });
    } catch (err) { 
      showToast('Error: ' + err.message); 
    }
  };

  // Auto-fill Salary Form when Employee is selected
  const handlePayEmpChange = (empId) => {
    const emp = data.employees.find(e => e.id === empId);
    const pendingAdv = data.empAdvances.filter(a => a.employee_id === empId && a.status === 'Pending').reduce((sum, a) => sum + a.amount, 0);
    setPayForm({ ...payForm, empId, base: emp?.salary || 0, adv_ded: pendingAdv });
  };

  // 1. AI DASHBOARD LAYER
  if (page === 'ai_dashboard') {
    const activeInvoices = data.invoices.filter(i => !i.invoice_no.startsWith('REF-') && i.status !== 'Draft');
    const tSales = activeInvoices.reduce((s, i) => s + (i.total || 0), 0);
    const tProfit = activeInvoices.reduce((s, i) => s + (i.profit || 0), 0);
    const pendingPayments = activeInvoices.filter(i => i.due_amount > 0);
    const totalDue = pendingPayments.reduce((s, i) => s + i.due_amount, 0);
    
    const empProfits = {};
    activeInvoices.forEach(inv => {
      const empName = inv.employees?.name || 'Unknown';
      if (!empProfits[empName]) empProfits[empName] = 0;
      empProfits[empName] += inv.profit || 0;
    });
    const topEmployee = Object.keys(empProfits).map(k => ({ name: k, profit: empProfits[k] })).sort((a,b) => b.profit - a.profit)[0];

    const aiInsights = [];
    if (totalDue > 0) aiInsights.push(`⚠️ You have ${totalDue.toFixed(2)} SAR pending from ${pendingPayments.length} customers. Follow up needed.`);
    if (topEmployee) aiInsights.push(`🏆 ${topEmployee.name} is your top performer with ${topEmployee.profit.toFixed(2)} SAR in profit.`);
    if (tProfit < 1000) aiInsights.push("📉 Profits are low this month. Consider pushing tour packages or visa services.");

    return (
      <div>
        <div style={{ background: 'linear-gradient(135deg, #0F172A, #1E293B)', color: 'white', padding: '30px', borderRadius: '16px', marginBottom: '20px', boxShadow: '0 10px 15px rgba(0,0,0,0.1)' }}>
          <h2 style={{ margin: 0, fontSize: '28px', color: '#F59E0B' }}>🤖 {tr.ai_dashboard || 'AI ERP Assistant'}</h2>
          <p style={{ margin: '5px 0 0', opacity: 0.9, fontSize: '16px' }}>Real-time business insights based on your data.</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '20px' }}>
          <div style={{ background: 'linear-gradient(135deg, #047857, #059669)', color: 'white', padding: '25px', borderRadius: '16px', boxShadow: '0 4px 6px rgba(5, 150, 105, 0.2)' }}><h3 style={{ margin: '0 0 10px', opacity: 0.9 }}>Monthly Sales</h3><h2 style={{ margin: 0, fontSize: '28px' }}>{tSales.toFixed(2)} SAR</h2></div>
          <div style={{ background: 'linear-gradient(135deg, #1E3A8A, #2563EB)', color: 'white', padding: '25px', borderRadius: '16px', boxShadow: '0 4px 6px rgba(37, 99, 235, 0.2)' }}><h3 style={{ margin: '0 0 10px', opacity: 0.9 }}>Net Profit</h3><h2 style={{ margin: 0, fontSize: '28px' }}>{tProfit.toFixed(2)} SAR</h2></div>
          <div style={{ background: 'linear-gradient(135deg, #B91C1C, #EF4444)', color: 'white', padding: '25px', borderRadius: '16px', boxShadow: '0 4px 6px rgba(239, 68, 68, 0.2)' }}><h3 style={{ margin: '0 0 10px', opacity: 0.9 }}>Pending Dues</h3><h2 style={{ margin: 0, fontSize: '28px' }}>{totalDue.toFixed(2)} SAR</h2></div>
        </div>
        <div style={{...styles.card, borderTop: '5px solid #F59E0B'}}>
          <h3 style={{ color: '#0F172A', borderBottom: '2px solid #E2E8F0', paddingBottom: '15px', marginTop: 0 }}>🧠 AI Insights & Action Items</h3>
          <ul style={{ marginTop: '15px', paddingInlineStart: '20px' }}>
            {aiInsights.length === 0 ? <li style={{fontSize: '15px'}}>No critical alerts. Business is running smoothly!</li> : aiInsights.map((ins, i) => <li key={i} style={{ marginBottom: '12px', fontSize: '15px', color: '#334155' }}>{ins}</li>)}
          </ul>
        </div>
      </div>
    );
  }

  // 2. QUOTATIONS PANEL
  if (page === 'quotations') {
    const quotations = data.invoices.filter(i => i.status === 'Draft');

    const handleCreateQuote = async (e) => {
      e.preventDefault();
      try {
        const quoteNo = `QUO-${Date.now()}`;
        const payload = { invoice_no: quoteNo, sector: quoteForm.service_type, total_sell: parseFloat(quoteForm.price) || 0, total: parseFloat(quoteForm.price) || 0, invoice_date: today, status: 'Draft', tenant_id: userProfile.tenant_id };
        const { data: newQuote, error } = await supabase.from('invoices').insert([payload]).select().single();
        if (error) throw error;
        setData(prev => ({ ...prev, invoices: [newQuote, ...prev.invoices] }));
        showToast('Quotation Created!');
        setQuoteForm({ customer_name: '', service_type: 'Flight Ticket', price: '', valid_until: today });
      } catch (err) { showToast('Error: ' + err.message); }
    };

    const convertToInvoice = async (quote) => {
      try {
        const { error } = await supabase.from('invoices').update({ status: 'Confirmed' }).eq('id', quote.id);
        if (error) throw error;
        setData(prev => ({ ...prev, invoices: prev.invoices.map(i => i.id === quote.id ? { ...i, status: 'Confirmed' } : i) }));
        showToast('Converted to Invoice!');
      } catch (err) { showToast('Error: ' + err.message); }
    };

    return (
      <div>
        <div style={{ background: 'linear-gradient(135deg, #1E3A8A, #2563EB)', color: 'white', padding: '30px', borderRadius: '16px', marginBottom: '20px' }}>
          <h2 style={{ margin: 0, fontSize: '24px' }}>📄 Quotation Management</h2>
          <p style={{ margin: '5px 0 0', opacity: 0.9 }}>Create draft quotes and convert them to invoices when confirmed.</p>
        </div>
        <div style={styles.card}>
          <h3 style={{marginTop: 0, color: '#0F172A'}}>Create New Quotation</h3>
          <form onSubmit={handleCreateQuote} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px' }}>
            <div><label style={styles.label}>Customer Name</label><input style={styles.input} value={quoteForm.customer_name} onChange={e => setQuoteForm({...quoteForm, customer_name: e.target.value})} required /></div>
            <div><label style={styles.label}>Service Type</label><select style={styles.input} value={quoteForm.service_type} onChange={e => setQuoteForm({...quoteForm, service_type: e.target.value})}><option>Flight Ticket</option><option>Tour Package</option><option>Visa</option></select></div>
            <div><label style={styles.label}>Estimated Price (SAR)</label><input type="number" style={styles.input} value={quoteForm.price} onChange={e => setQuoteForm({...quoteForm, price: e.target.value})} required /></div>
            <div><label style={styles.label}>Valid Until</label><input type="date" style={styles.input} value={quoteForm.valid_until} onChange={e => setQuoteForm({...quoteForm, valid_until: e.target.value})} required /></div>
            <button type="submit" style={{ ...styles.btnPrimary, gridColumn: '1 / -1', padding: '15px' }}>Generate Quotation</button>
          </form>
        </div>
        <div style={{ background: 'white', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 4px 6px rgba(0,0,0,0.05)' }}>
          <div style={{ padding: '20px', borderBottom: '1px solid #E2E8F0' }}><h3 style={{ margin: 0, color: '#0F172A' }}>Recent Quotations (Drafts)</h3></div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '600px' }}>
              <thead><tr><th style={styles.tableHeader}>Quote No</th><th style={styles.tableHeader}>Service</th><th style={styles.tableHeader}>Amount</th><th style={styles.tableHeader}>Action</th></tr></thead>
              <tbody>
                {quotations.length === 0 ? <tr><td colSpan="4" style={{padding:'30px', textAlign:'center', color:'#94A3B8'}}>No quotations found.</td></tr> : quotations.map(q => (
                  <tr key={q.id} style={{ borderBottom: '1px solid #F1F5F9' }}>
                    <td style={styles.tableCell}>{q.invoice_no}</td>
                    <td style={styles.tableCell}>{q.sector}</td>
                    <td style={styles.tableCell}>{(q.total || 0).toFixed(2)} SAR</td>
                    <td style={styles.tableCell}><button onClick={() => convertToInvoice(q)} style={styles.btnSuccess}>Convert to Invoice</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // 3. ADVANCED HR & ATTENDANCE
  if (page === 'hr_advanced') {
    return (
      <div>
        <h2 style={{ color: '#0F172A', marginBottom: '20px' }}>🎯 Employee Targets & Performance</h2>
        <div style={{ background: 'white', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 4px 6px rgba(0,0,0,0.05)' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '700px' }}>
              <thead>
                <tr>
                  <th style={styles.tableHeader}>Employee</th>
                  <th style={styles.tableHeader}>{tr.target || 'Target'} (SAR)</th>
                  <th style={styles.tableHeader}>{tr.achieved || 'Achieved'} (SAR)</th>
                  <th style={styles.tableHeader}>{tr.percentage || 'Percentage'}</th>
                  <th style={styles.tableHeader}>Action</th>
                </tr>
              </thead>
              <tbody>
                {data.employees.map(emp => {
                  const empInv = data.invoices.filter(i => i.employee_id === emp.id && !i.invoice_no.startsWith('REF-') && i.status !== 'Draft');
                  const achieved = empInv.reduce((s, i) => s + (i.total || 0), 0);
                  const target = emp.target || 0;
                  const perc = target > 0 ? (achieved / target) * 100 : 0;
                  return (
                    <tr key={emp.id} style={{ borderBottom: '1px solid #F1F5F9' }}>
                      <td style={{...styles.tableCell, fontWeight: 'bold'}}>{emp.name}</td>
                      <td style={styles.tableCell}>
                        {editTargetId === emp.id ? (
                          <input type="number" value={targetVal} onChange={e => setTargetVal(e.target.value)} style={{...styles.input, width: '100px', margin: 0}} />
                        ) : (
                          <span style={{ cursor: 'pointer', textDecoration: 'underline' }} onClick={() => { setEditTargetId(emp.id); setTargetVal(target); }}>{target.toFixed(2)}</span>
                        )}
                      </td>
                      <td style={{...styles.tableCell, color: '#059669'}}>{achieved.toFixed(2)}</td>
                      <td style={styles.tableCell}>
                        <div style={{ background: '#E2E8F0', borderRadius: '10px', overflow: 'hidden', width: '100%', height: '20px', display: 'flex', alignItems: 'center' }}>
                          <div style={{ width: `${Math.min(perc, 100)}%`, background: perc >= 100 ? '#059669' : '#FBBF24', height: '100%', transition: 'width 0.5s' }}></div>
                        </div>
                        <small style={{ fontWeight: 'bold', color: '#475569' }}>{perc.toFixed(0)}%</small>
                      </td>
                      <td style={styles.tableCell}>
                        {editTargetId === emp.id ? <button onClick={() => saveTarget(emp.id)} style={styles.btnSuccess}>{tr.save || 'Save'}</button> : <button onClick={() => { setEditTargetId(emp.id); setTargetVal(target); }} style={styles.btnWarning}>{tr.edit || 'Edit'}</button>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
        
        <div style={styles.card}>
          <h3 style={{marginTop: 0, color: '#0F172A'}}>📅 Daily Time-Based Attendance & Leave</h3>
          <p style={{ color: '#64748b', fontSize: '14px', marginBottom: '15px' }}>Mark Check-in and Check-out time. System will automatically calculate Overtime ({'>9 hrs'}) and Salary Deduction ({'<8 hrs'}).</p>
          <form onSubmit={markAttendance} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr)) auto', gap: '15px', alignItems: 'flex-end' }}>
            <div>
              <label style={styles.label}>{tr.attendanceDate || 'Date'}</label>
              <input type="date" style={styles.input} value={attForm.date} onChange={e => setAttForm({...attForm, date: e.target.value})} required />
            </div>
            <div>
              <label style={styles.label}>{tr.selectEmployee || 'Employee'}</label>
              <select style={styles.input} value={attForm.empId} onChange={e => setAttForm({...attForm, empId: e.target.value})} required>
                <option value="">Select Employee</option>
                {data.employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </div>
            <div>
              <label style={styles.label}>{tr.status || 'Status'}</label>
              <select style={styles.input} value={attForm.status} onChange={e => setAttForm({...attForm, status: e.target.value})}>
                <option>{tr.present || 'Present'}</option><option>{tr.leave || 'Leave'}</option><option>{tr.absent || 'Absent'}</option>
              </select>
            </div>
            {attForm.status === 'Present' ? (
              <>
                <div>
                  <label style={styles.label}>{tr.checkInTime || 'Check-In'}</label>
                  <input type="time" style={styles.input} value={attForm.checkIn} onChange={e => setAttForm({...attForm, checkIn: e.target.value})} required />
                </div>
                <div>
                  <label style={styles.label}>{tr.checkOutTime || 'Check-Out'}</label>
                  <input type="time" style={styles.input} value={attForm.checkOut} onChange={e => setAttForm({...attForm, checkOut: e.target.value})} required />
                </div>
              </>
            ) : (
              <>
                <div>
                  <label style={styles.label}>Leave Start</label>
                  <input type="date" style={styles.input} value={attForm.leaveStart} onChange={e => setAttForm({...attForm, leaveStart: e.target.value})} required />
                </div>
                <div>
                  <label style={styles.label}>Leave End</label>
                  <input type="date" style={styles.input} value={attForm.leaveEnd} onChange={e => setAttForm({...attForm, leaveEnd: e.target.value})} required />
                </div>
              </>
            )}
            <button type="submit" style={{...styles.btnPrimary, height: '42px'}}>{tr.mark || 'Mark'}</button>
          </form>
          
          <div style={{ overflowX: 'auto', marginTop: '20px' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '800px' }}>
              <thead><tr style={{ background: '#F8FAFC' }}>
                <th style={styles.tableHeader}>Date</th>
                <th style={styles.tableHeader}>Employee</th>
                <th style={styles.tableHeader}>Check-In</th>
                <th style={styles.tableHeader}>Check-Out</th>
                <th style={styles.tableHeader}>{tr.overtime || 'Overtime'}</th>
                <th style={styles.tableHeader}>{tr.deduction || 'Deduction'}</th>
                <th style={styles.tableHeader}>{tr.status || 'Status'}</th>
              </tr></thead>
              <tbody>
                {attendance.length === 0 ? <tr><td colSpan="7" style={{padding:'20px', textAlign:'center', color:'#94A3B8'}}>No attendance marked yet.</td></tr> : attendance.slice(0, 15).map(a => (
                  <tr key={a.id} style={{ borderBottom: '1px solid #F1F5F9' }}>
                    <td style={styles.tableCell}>{a.date}</td>
                    <td style={styles.tableCell}>{a.employees?.name || 'N/A'}</td>
                    <td style={styles.tableCell}>{a.check_in || '-'}</td>
                    <td style={styles.tableCell}>{a.check_out || '-'}</td>
                    <td style={{...styles.tableCell, color: '#059669', fontWeight: 'bold'}}>{a.overtime ? `${a.overtime} hrs` : '0'}</td>
                    <td style={{...styles.tableCell, color: '#EF4444', fontWeight: 'bold'}}>{a.deduction ? `${a.deduction} hrs` : '0'}</td>
                    <td style={{...styles.tableCell, color: a.status === 'Present' ? '#059669' : '#D97706', fontWeight: 'bold'}}>{a.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* PAY SALARY & GENERATE SLIP */}
        <div style={styles.card}>
          <h3 style={{marginTop: 0, color: '#0F172A'}}>💰 {tr.paySalary || 'Pay Salary'}</h3>
          <p style={{ color: '#64748b', fontSize: '14px', marginBottom: '15px' }}>Select Employee to Auto-Fill Basic Salary & Pending Advances. Commission & Overtime will auto-calculate from Sales & Attendance.</p>
          <form onSubmit={handlePaySalary} style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr 1fr 1fr 1fr 1fr auto', gap: '15px', alignItems: 'flex-end' }}>
            <div>
              <label style={styles.label}>{tr.selectEmployee || 'Employee'}</label>
              <select name="emp" style={styles.input} value={payForm.empId} onChange={e => handlePayEmpChange(e.target.value)} required>
                <option value="">Select Employee</option>
                {data.employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </div>
            <div>
              <label style={styles.label}>{tr.baseSalary || 'Base'}</label>
              <input name="base" type="number" style={styles.input} value={payForm.base} onChange={e => setPayForm({...payForm, base: e.target.value})} required />
            </div>
            <div>
              <label style={styles.label}>{tr.commission || 'Commission %'}</label>
              <input name="comm" type="number" style={styles.input} value={payForm.comm} onChange={e => setPayForm({...payForm, comm: e.target.value})} required />
            </div>
            <div>
              <label style={styles.label}>{tr.advDed || 'Adv. Deduct'}</label>
              <input name="adv_ded" type="number" style={styles.input} value={payForm.adv_ded} onChange={e => setPayForm({...payForm, adv_ded: e.target.value})} required />
            </div>
            <div>
              <label style={styles.label}>{tr.gift || 'Gift'}</label>
              <input name="gift" type="number" style={styles.input} value={payForm.gift} onChange={e => setPayForm({...payForm, gift: e.target.value})} required />
            </div>
            <div>
              <label style={styles.label}>{tr.month || 'Month'}</label>
              <input name="month" type="text" style={styles.input} value={payForm.month} onChange={e => setPayForm({...payForm, month: e.target.value})} required />
            </div>
            <div>
              <label style={styles.label}>{tr.mode || 'Mode'}</label>
              <select name="mode" style={styles.input} value={payForm.mode} onChange={e => setPayForm({...payForm, mode: e.target.value})}><option>Cash</option><option>Bank Transfer</option></select>
            </div>
            <button type="submit" style={{...styles.btnPrimary, height: '42px'}}>Pay</button>
          </form>
        </div>

        <div style={{ background: 'white', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 4px 6px rgba(0,0,0,0.05)' }}>
          <div style={{ padding: '20px', borderBottom: '1px solid #E2E8F0' }}><h3 style={{ margin: 0, color: '#0F172A' }}>📋 {tr.generateSlip || 'Generate Salary Slip'}</h3></div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '600px' }}>
              <thead>
                <tr>
                  <th style={styles.tableHeader}>Employee</th>
                  <th style={styles.tableHeader}>Month</th>
                  <th style={styles.tableHeader}>Net Paid</th>
                  <th style={styles.tableHeader}>Action</th>
                </tr>
              </thead>
              <tbody>
                {data.payroll.length === 0 ? <tr><td colSpan="4" style={{padding:'30px', textAlign:'center', color:'#94A3B8'}}>No salary paid yet.</td></tr> : data.payroll.map(p => (
                  <tr key={p.id} style={{ borderBottom: '1px solid #F1F5F9' }}>
                    <td style={{...styles.tableCell, fontWeight: 'bold'}}>{p.employees?.name || 'N/A'}</td>
                    <td style={styles.tableCell}>{p.month}</td>
                    <td style={{...styles.tableCell, color: '#059669', fontWeight: 'bold'}}>{(p.amount || 0).toFixed(2)} SAR</td>
                    <td style={styles.tableCell}>
                      <button onClick={() => handleGenerateSlip(p)} style={styles.btnInfo}>Download Slip</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
