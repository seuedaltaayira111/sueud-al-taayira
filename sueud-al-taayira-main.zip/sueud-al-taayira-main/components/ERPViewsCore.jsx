'use client';
import { useState, useMemo } from 'react';

export default function ERPViewsCore(props) {
  const {
    page, data, lang, tr, setPage, modal, setModal,
    invForm, setInvForm, editInvId, setEditInvId,
    handleCreateInvoice, handleEditInvoice, handleDeleteInvoice,
    openPreview, openRefundModal, handleQuickSettle,
    handleDownloadPDF, printInvoice, shareWhatsApp, shareEmail,
    handleEditCust, handleEditCorp, handleEditCred, handleDelete,
    custForm, setCustForm, corpForm, setCorpForm, creditorForm, setCreditorForm,
    handleAddEditCust, handleAddEditCorp, handleAddEditCred,
    editCustId, editCorpId, editCredId,
    setEditCustId, setEditCorpId, setEditCredId,
    showToast, today, userProfile
  } = props;

  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);

  const t = (key, fallback) => tr?.[key] || fallback || key;
  const fmt = (n) => (n || 0).toFixed(2) + ' SAR';

  const s = {
    container: { padding: '20px', background: '#0F172A', minHeight: '100vh', color: '#E2E8F0' },
    card: { background: '#1E293B', borderRadius: '12px', padding: '20px', marginBottom: '20px', border: '1px solid #334155' },
    header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '10px' },
    title: { fontSize: '24px', fontWeight: '700', color: '#FBBF24', display: 'flex', alignItems: 'center', gap: '10px', margin: 0 },
    input: { padding: '10px 15px', background: '#0F172A', border: '1px solid #475569', borderRadius: '8px', color: '#E2E8F0', fontSize: '14px', outline: 'none', minWidth: '180px' },
    select: { padding: '10px 15px', background: '#0F172A', border: '1px solid #475569', borderRadius: '8px', color: '#E2E8F0', fontSize: '14px', outline: 'none' },
    btn: { padding: '10px 20px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontWeight: '600', fontSize: '13px' },
    btnPrimary: { background: 'linear-gradient(135deg, #2563EB, #1D4ED8)', color: '#fff' },
    btnSuccess: { background: 'linear-gradient(135deg, #059669, #047857)', color: '#fff' },
    btnDanger: { background: 'linear-gradient(135deg, #DC2626, #B91C1C)', color: '#fff' },
    btnWarning: { background: 'linear-gradient(135deg, #F59E0B, #D97706)', color: '#0F172A' },
    btnGhost: { background: 'transparent', border: '1px solid #475569', color: '#94A3B8' },
    table: { width: '100%', borderCollapse: 'collapse', fontSize: '13px' },
    th: { padding: '12px', background: '#0F172A', color: '#FBBF24', textAlign: 'left', fontWeight: '600', fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px', borderBottom: '2px solid #334155' },
    td: { padding: '12px', borderBottom: '1px solid #1E293B', color: '#CBD5E1' },
    tdRight: { padding: '12px', borderBottom: '1px solid #1E293B', color: '#CBD5E1', textAlign: 'right', fontWeight: '600' },
    tdCenter: { padding: '12px', borderBottom: '1px solid #1E293B', color: '#CBD5E1', textAlign: 'center' },
    badge: { padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: '600', display: 'inline-block' },
    badgePaid: { background: '#065F46', color: '#34D399' },
    badgeUnpaid: { background: '#78350F', color: '#FBBF24' },
    statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '15px', marginBottom: '20px' },
    statCard: { background: 'linear-gradient(135deg, #1E293B, #0F172A)', padding: '18px', borderRadius: '12px', border: '1px solid #334155' },
    statLabel: { fontSize: '11px', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.5px' },
    statValue: { fontSize: '22px', fontWeight: '700', color: '#FBBF24', marginTop: '5px' },
    emptyState: { textAlign: 'center', padding: '60px 20px', color: '#64748B' },
    emptyIcon: { fontSize: '60px', marginBottom: '15px' },
    actionsCell: { display: 'flex', gap: '4px', flexWrap: 'wrap', justifyContent: 'center' },
    actionBtn: { padding: '6px 10px', borderRadius: '6px', border: 'none', cursor: 'pointer', fontSize: '11px', fontWeight: '600' },
    formGroup: { marginBottom: '15px' },
    formLabel: { display: 'block', marginBottom: '5px', color: '#94A3B8', fontSize: '13px', fontWeight: '600' },
    formInput: { width: '100%', padding: '10px 15px', background: '#0F172A', border: '1px solid #475569', borderRadius: '8px', color: '#E2E8F0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' },
    formRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' },
    pageBtn: { padding: '8px 15px', background: '#1E293B', border: '1px solid #475569', borderRadius: '6px', color: '#E2E8F0', cursor: 'pointer' }
  };

  const filteredInvoices = useMemo(() => {
    let inv = (data.invoices || []).filter(i => !i.invoice_no?.startsWith('REF-'));
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      inv = inv.filter(i =>
        (i.invoice_no || '').toLowerCase().includes(search) ||
        (i.customers?.name || '').toLowerCase().includes(search) ||
        (i.airline || '').toLowerCase().includes(search) ||
        (i.pnr || '').toLowerCase().includes(search)
      );
    }
    if (dateFilter) inv = inv.filter(i => i.invoice_date === dateFilter);
    if (statusFilter) inv = inv.filter(i => i.status === statusFilter);
    return inv;
  }, [data.invoices, searchTerm, dateFilter, statusFilter]);

  const filteredRefunds = useMemo(() => {
    let ref = (data.invoices || []).filter(i => i.invoice_no?.startsWith('REF-'));
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      ref = ref.filter(i =>
        (i.invoice_no || '').toLowerCase().includes(search) ||
        (i.old_customer_name || i.customers?.name || '').toLowerCase().includes(search)
      );
    }
    return ref;
  }, [data.invoices, searchTerm]);

  const paginate = (list) => {
    const start = (currentPage - 1) * rowsPerPage;
    return list.slice(start, start + rowsPerPage);
  };

  const totalPages = (list) => Math.ceil((list?.length || 0) / rowsPerPage);

  // ═══ DASHBOARD ═══
  if (page === 'dashboard') {
    const invoices = (data.invoices || []).filter(i => !i.invoice_no?.startsWith('REF-'));
    const totalRevenue = invoices.reduce((s, i) => s + (i.total || 0), 0);
    const totalPaid = invoices.reduce((s, i) => s + (i.paid_amount || 0), 0);
    const totalDue = invoices.reduce((s, i) => s + (i.due_amount || 0), 0);
    const totalProfit = invoices.reduce((s, i) => s + (i.profit || 0), 0);
    const totalExpenses = (data.expenses || []).reduce((s, e) => s + (e.amount || 0), 0);
    const unpaidCount = invoices.filter(i => i.status === 'Unpaid').length;
    const portalBalance = (data.portals || []).reduce((s, p) => s + (p.current_balance || 0), 0);

    return (
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>📊 {t('dashboard', 'Dashboard')}</h1>
          <div style={{ color: '#94A3B8', fontSize: '14px' }}>
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>

        <div style={s.statsGrid}>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Revenue</div>
            <div style={{ ...s.statValue, color: '#34D399' }}>{fmt(totalRevenue)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Paid</div>
            <div style={{ ...s.statValue, color: '#34D399' }}>{fmt(totalPaid)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Outstanding</div>
            <div style={{ ...s.statValue, color: totalDue > 0 ? '#FCA5A5' : '#34D399' }}>{fmt(totalDue)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Unpaid Invoices</div>
            <div style={{ ...s.statValue, color: unpaidCount > 0 ? '#FBBF24' : '#34D399' }}>{unpaidCount}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Profit</div>
            <div style={{ ...s.statValue, color: '#FBBF24' }}>{fmt(totalProfit)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Expenses</div>
            <div style={{ ...s.statValue, color: '#FCA5A5' }}>{fmt(totalExpenses)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Net Profit</div>
            <div style={{ ...s.statValue, color: (totalProfit - totalExpenses) >= 0 ? '#34D399' : '#FCA5A5' }}>{fmt(totalProfit - totalExpenses)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Portal Balance</div>
            <div style={{ ...s.statValue, color: portalBalance >= 0 ? '#60A5FA' : '#FCA5A5' }}>{fmt(portalBalance)}</div>
          </div>
        </div>

        <div style={s.card}>
          <h3 style={{ color: '#FBBF24', marginBottom: '15px', marginTop: 0 }}>⚡ Quick Actions</h3>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button style={{ ...s.btn, ...s.btnPrimary }} onClick={() => setPage('create')}>+ {t('create', 'Create Invoice')}</button>
            <button style={{ ...s.btn, ...s.btnSuccess }} onClick={() => setPage('list')}>📋 {t('list', 'View Invoices')}</button>
            <button style={{ ...s.btn, ...s.btnWarning }} onClick={() => setPage('refunds')}>🔄 {t('refunds', 'Refunds')}</button>
            <button style={{ ...s.btn, ...s.btnGhost }} onClick={() => setPage('customers')}>👥 {t('customers', 'Customers')}</button>
            <button style={{ ...s.btn, ...s.btnGhost }} onClick={() => setPage('reports')}>📊 Reports</button>
          </div>
        </div>

        <div style={s.card}>
          <h3 style={{ color: '#FBBF24', marginBottom: '15px', marginTop: 0 }}>📄 Recent Invoices</h3>
          {invoices.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '30px', color: '#64748B' }}>
              <p>No invoices yet. Create your first invoice!</p>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={s.table}>
                <thead>
                  <tr>
                    <th style={s.th}>Inv No</th>
                    <th style={s.th}>Date</th>
                    <th style={s.th}>Customer</th>
                    <th style={s.th}>Airline</th>
                    <th style={{ ...s.th, textAlign: 'right' }}>Total</th>
                    <th style={{ ...s.th, textAlign: 'right' }}>Due</th>
                    <th style={{ ...s.th, textAlign: 'center' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {invoices.slice(0, 10).map(inv => (
                    <tr key={inv.id} style={{ background: inv.status === 'Unpaid' ? 'rgba(251,191,36,0.03)' : 'transparent' }}>
                      <td style={{ ...s.td, fontWeight: '700', color: '#60A5FA' }}>{inv.invoice_no}</td>
                      <td style={s.td}>{inv.invoice_date}</td>
                      <td style={s.td}>{inv.customers?.name || inv.corporates?.name || 'N/A'}</td>
                      <td style={s.td}>{inv.airline || '-'}</td>
                      <td style={s.tdRight}>{fmt(inv.total)}</td>
                      <td style={{ ...s.tdRight, color: inv.due_amount > 0 ? '#FCA5A5' : '#34D399' }}>{fmt(inv.due_amount)}</td>
                      <td style={s.tdCenter}>
                        <span style={{ ...s.badge, ...(inv.status === 'Paid' ? s.badgePaid : s.badgeUnpaid) }}>{inv.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div style={s.card}>
          <h3 style={{ color: '#FBBF24', marginBottom: '15px', marginTop: 0 }}>🛫 Portal Balances</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr)', gap: '10px' }}>
            {(data.portals || []).map(p => (
              <div key={p.id} style={{ background: '#0F172A', padding: '15px', borderRadius: '8px', border: '1px solid #334155', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: '#CBD5E1', fontSize: '13px' }}>{p.name}</span>
                <span style={{ color: (p.current_balance || 0) < 1000 ? '#FCA5A5' : '#34D399', fontWeight: '700', fontSize: '14px' }}>{fmt(p.current_balance)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ═══ INVOICES LIST ═══
  if (page === 'list') {
    const totalRevenue = filteredInvoices.reduce((s, i) => s + (i.total || 0), 0);
    const totalDue = filteredInvoices.reduce((s, i) => s + (i.due_amount || 0), 0);

    return (
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>📋 {t('list', 'Invoices')}</h1>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <input style={s.input} placeholder={t('search', 'Search...')} value={searchTerm} onChange={e => { setSearchTerm(e.target.value); setCurrentPage(1); }} />
            <input type="date" style={{ ...s.input, minWidth: '150px' }} value={dateFilter} onChange={e => { setDateFilter(e.target.value); setCurrentPage(1); }} />
            <select style={s.select} value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setCurrentPage(1); }}>
              <option value="">All Status</option>
              <option value="Paid">Paid</option>
              <option value="Unpaid">Unpaid</option>
            </select>
            <select style={s.select} value={rowsPerPage} onChange={e => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}>
              <option value="25">25 rows</option>
              <option value="50">50 rows</option>
              <option value="100">100 rows</option>
            </select>
            <button style={{ ...s.btn, ...s.btnSuccess }} onClick={() => setPage('create')}>+ {t('create', 'New')}</button>
          </div>
        </div>

        <div style={s.statsGrid}>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Invoices</div>
            <div style={s.statValue}>{filteredInvoices.length}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Revenue</div>
            <div style={{ ...s.statValue, color: '#34D399' }}>{fmt(totalRevenue)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Due</div>
            <div style={{ ...s.statValue, color: totalDue > 0 ? '#FCA5A5' : '#34D399' }}>{fmt(totalDue)}</div>
          </div>
        </div>

        <div style={s.card}>
          {paginate(filteredInvoices).length === 0 ? (
            <div style={s.emptyState}>
              <div style={s.emptyIcon}>📄</div>
              <h3>No Invoices Found</h3>
              <p>Create an invoice to get started!</p>
              <button style={{ ...s.btn, ...s.btnPrimary, marginTop: '15px' }} onClick={() => setPage('create')}>+ Create Invoice</button>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={s.table}>
                <thead>
                  <tr>
                    <th style={s.th}>{t('invNo', 'Inv No')}</th>
                    <th style={s.th}>Date</th>
                    <th style={s.th}>Customer</th>
                    <th style={s.th}>Airline</th>
                    <th style={s.th}>PNR</th>
                    <th style={s.th}>Service</th>
                    <th style={{ ...s.th, textAlign: 'right' }}>{t('total', 'Total')}</th>
                    <th style={{ ...s.th, textAlign: 'right' }}>{t('due', 'Due')}</th>
                    <th style={{ ...s.th, textAlign: 'center' }}>Status</th>
                    <th style={{ ...s.th, textAlign: 'center' }}>{t('actions', 'Actions')}</th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(filteredInvoices).map(inv => (
                    <tr key={inv.id} style={{ background: inv.status === 'Unpaid' ? 'rgba(251,191,36,0.03)' : 'transparent' }}>
                      <td style={{ ...s.td, fontWeight: '700', color: '#60A5FA' }}>{inv.invoice_no}</td>
                      <td style={s.td}>{inv.invoice_date}</td>
                      <td style={s.td}>{inv.customers?.name || inv.corporates?.name || 'N/A'}</td>
                      <td style={s.td}>{inv.airline || '-'}</td>
                      <td style={{ ...s.td, color: '#60A5FA', fontWeight: '600' }}>{inv.pnr || '-'}</td>
                      <td style={s.td}>{inv.service_type || '-'}</td>
                      <td style={s.tdRight}>{fmt(inv.total)}</td>
                      <td style={{ ...s.tdRight, color: inv.due_amount > 0 ? '#FCA5A5' : '#34D399' }}>{fmt(inv.due_amount)}</td>
                      <td style={s.tdCenter}>
                        <span style={{ ...s.badge, ...(inv.status === 'Paid' ? s.badgePaid : s.badgeUnpaid) }}>{inv.status}</span>
                      </td>
                      <td style={s.tdCenter}>
                        <div style={s.actionsCell}>
                          <button style={{ ...s.actionBtn, background: '#1E3A8A', color: '#93C5FD' }} onClick={() => openPreview(inv)} title="Preview">👁</button>
                          <button style={{ ...s.actionBtn, background: '#065F46', color: '#34D399' }} onClick={() => handleEditInvoice(inv)} title="Edit">✏️</button>
                          <button style={{ ...s.actionBtn, background: '#7F1D1D', color: '#FCA5A5' }} onClick={() => openRefundModal(inv)} title="Refund">🔄</button>
                          {inv.due_amount > 0 && (
                            <button style={{ ...s.actionBtn, background: '#78350F', color: '#FBBF24' }} onClick={() => handleQuickSettle(inv)} title="Settle">💰</button>
                          )}
                          <button style={{ ...s.actionBtn, background: '#4338CA', color: '#A5B4FC' }} onClick={() => printInvoice(inv)} title="Print">🖨</button>
                          <button style={{ ...s.actionBtn, background: '#991B1B', color: '#FECACA' }} onClick={() => handleDeleteInvoice(inv)} title="Delete">🗑</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {filteredInvoices.length > rowsPerPage && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '15px', padding: '10px 0' }}>
            <div style={{ color: '#94A3B8', fontSize: '13px' }}>
              Showing {Math.min((currentPage - 1) * rowsPerPage + 1, filteredInvoices.length)} - {Math.min(currentPage * rowsPerPage, filteredInvoices.length)} of {filteredInvoices.length}
            </div>
            <div style={{ display: 'flex', gap: '5px' }}>
              <button style={s.pageBtn} disabled={currentPage === 1} onClick={() => setCurrentPage(p => p - 1)}>← Prev</button>
              <span style={{ padding: '8px 15px', background: '#2563EB', borderRadius: '6px', color: '#fff', fontWeight: '600' }}>{currentPage}</span>
              <button style={s.pageBtn} disabled={currentPage >= totalPages(filteredInvoices)} onClick={() => setCurrentPage(p => p + 1)}>Next →</button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ═══ REFUNDS LIST ═══
  if (page === 'refunds') {
    const totalCustRefund = filteredRefunds.reduce((s, r) => s + (r.refund_customer || 0), 0);
    const totalCompRefund = filteredRefunds.reduce((s, r) => s + (r.refund_company || 0), 0);

    return (
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>🔄 {t('refunds', 'Refunds')}</h1>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <input style={s.input} placeholder="Search refunds..." value={searchTerm} onChange={e => { setSearchTerm(e.target.value); setCurrentPage(1); }} />
            <select style={s.select} value={rowsPerPage} onChange={e => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}>
              <option value="25">25 rows</option>
              <option value="50">50 rows</option>
              <option value="100">100 rows</option>
            </select>
          </div>
        </div>

        <div style={s.statsGrid}>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Refunds</div>
            <div style={s.statValue}>{filteredRefunds.length}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Refunded to Customers</div>
            <div style={{ ...s.statValue, color: '#FCA5A5' }}>{fmt(totalCustRefund)}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Refunded to Portals</div>
            <div style={{ ...s.statValue, color: '#60A5FA' }}>{fmt(totalCompRefund)}</div>
          </div>
        </div>

        <div style={s.card}>
          {paginate(filteredRefunds).length === 0 ? (
            <div style={s.emptyState}>
              <div style={s.emptyIcon}>🔄</div>
              <h3>No Refunds Found</h3>
              <p>Click the refund button on any invoice to create one!</p>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={s.table}>
                <thead>
                  <tr>
                    <th style={s.th}>Refund No</th>
                    <th style={s.th}>Date</th>
                    <th style={s.th}>Customer</th>
                    <th style={s.th}>Airline</th>
                    <th style={s.th}>PNR</th>
                    <th style={s.th}>Reason</th>
                    <th style={{ ...s.th, textAlign: 'right' }}>Cust Refund</th>
                    <th style={{ ...s.th, textAlign: 'right' }}>Portal Refund</th>
                    <th style={{ ...s.th, textAlign: 'right' }}>Original</th>
                    <th style={{ ...s.th, textAlign: 'center' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {paginate(filteredRefunds).map(ref => (
                    <tr key={ref.id}>
                      <td style={{ ...s.td, fontWeight: '700', color: '#FCA5A5' }}>{ref.invoice_no}</td>
                      <td style={s.td}>{ref.refund_date || ref.invoice_date}</td>
                      <td style={s.td}>{ref.old_customer_name || ref.customers?.name || 'N/A'}</td>
                      <td style={s.td}>{ref.airline || ref.old_airline || '-'}</td>
                      <td style={{ ...s.td, color: '#60A5FA' }}>{ref.pnr || ref.old_pnr || '-'}</td>
                      <td style={s.td}>{ref.refund_reason || '-'}</td>
                      <td style={{ ...s.tdRight, color: '#FCA5A5' }}>{fmt(ref.refund_customer)}</td>
                      <td style={{ ...s.tdRight, color: '#60A5FA' }}>{fmt(ref.refund_company)}</td>
                      <td style={s.tdRight}>{fmt(ref.old_sell_price)}</td>
                      <td style={s.tdCenter}>
                        <div style={s.actionsCell}>
                          <button style={{ ...s.actionBtn, background: '#1E3A8A', color: '#93C5FD' }} onClick={() => openPreview(ref)}>👁</button>
                          <button style={{ ...s.actionBtn, background: '#4338CA', color: '#A5B4FC' }} onClick={() => printInvoice(ref)}>🖨</button>
                          <button style={{ ...s.actionBtn, background: '#991B1B', color: '#FECACA' }} onClick={() => handleDeleteInvoice(ref)}>🗑</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ═══ CUSTOMERS ═══
  if (page === 'customers') {
    const filtered = (data.customers || []).filter(c =>
      !searchTerm || c.name?.toLowerCase().includes(searchTerm.toLowerCase()) || c.phone?.includes(searchTerm)
    );

    return (
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>👥 {t('customers', 'Customers')}</h1>
          <input style={s.input} placeholder="Search customers..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>

        <div style={s.card}>
          <h3 style={{ color: '#FBBF24', marginBottom: '15px', marginTop: 0 }}>{editCustId ? '✏️ Edit Customer' : '➕ Add Customer'}</h3>
          <form onSubmit={handleAddEditCust} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr auto', gap: '15px', alignItems: 'end' }}>
            <div>
              <label style={s.formLabel}>Name *</label>
              <input style={s.formInput} value={custForm?.name || ''} onChange={e => setCustForm(prev => ({...prev, name: e.target.value}))} required placeholder="Customer name" />
            </div>
            <div>
              <label style={s.formLabel}>Phone</label>
              <input style={s.formInput} value={custForm?.phone || ''} onChange={e => setCustForm(prev => ({...prev, phone: e.target.value}))} placeholder="Phone number" />
            </div>
            <div>
              <label style={s.formLabel}>Credit Balance</label>
              <input type="number" style={s.formInput} value={custForm?.store_credit || 0} onChange={e => setCustForm(prev => ({...prev, store_credit: parseFloat(e.target.value) || 0}))} />
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button type="submit" style={{ ...s.btn, ...s.btnSuccess, height: '44px' }}>
                {editCustId ? '💾 Update' : '➕ Add'}
              </button>
              {editCustId && (
                <button type="button" style={{ ...s.btn, ...s.btnGhost, height: '44px' }} onClick={() => { setEditCustId(null); setCustForm({ name: '', phone: '', store_credit: 0 }); }}>
                  ✕
                </button>
              )}
            </div>
          </form>
        </div>

        <div style={s.card}>
          <table style={s.table}>
            <thead>
              <tr>
                <th style={s.th}>Name</th>
                <th style={s.th}>Phone</th>
                <th style={s.th}>Type</th>
                <th style={{ ...s.th, textAlign: 'right' }}>Credit Balance</th>
                <th style={{ ...s.th, textAlign: 'right' }}>Credit Limit</th>
                <th style={{ ...s.th, textAlign: 'center' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id}>
                  <td style={{ ...s.td, fontWeight: '600' }}>{c.name}</td>
                  <td style={s.td}>{c.phone || '-'}</td>
                  <td style={s.td}>{c.type || 'Individual'}</td>
                  <td style={{ ...s.tdRight, color: '#A78BFA' }}>{fmt(c.store_credit)}</td>
                  <td style={{ ...s.tdRight, color: '#60A5FA' }}>{fmt(c.credit_limit)}</td>
                  <td style={s.tdCenter}>
                    <div style={s.actionsCell}>
                      <button style={{ ...s.actionBtn, background: '#065F46', color: '#34D399' }} onClick={() => handleEditCust(c)}>✏️</button>
                      <button style={{ ...s.actionBtn, background: '#991B1B', color: '#FECACA' }} onClick={() => handleDelete('customers', c.id)}>🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // ═══ CORPORATES ═══
  if (page === 'corporates') {
    const filtered = (data.corporates || []).filter(c =>
      !searchTerm || c.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>🏢 {t('corporates', 'Corporates')}</h1>
          <input style={s.input} placeholder="Search corporates..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>

        <div style={s.card}>
          <h3 style={{ color: '#FBBF24', marginBottom: '15px', marginTop: 0 }}>{editCorpId ? '✏️ Edit Corporate' : '➕ Add Corporate'}</h3>
          <form onSubmit={handleAddEditCorp} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr auto', gap: '15px', alignItems: 'end' }}>
            <div>
              <label style={s.formLabel}>Name *</label>
              <input style={s.formInput} value={corpForm?.name || ''} onChange={e => setCorpForm(prev => ({...prev, name: e.target.value}))} required />
            </div>
            <div>
              <label style={s.formLabel}>VAT No</label>
              <input style={s.formInput} value={corpForm?.vat_no || ''} onChange={e => setCorpForm(prev => ({...prev, vat_no: e.target.value}))} />
            </div>
            <div>
              <label style={s.formLabel}>Phone</label>
              <input style={s.formInput} value={corpForm?.phone || ''} onChange={e => setCorpForm(prev => ({...prev, phone: e.target.value}))} />
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button type="submit" style={{ ...s.btn, ...s.btnSuccess, height: '44px' }}>{editCorpId ? '💾' : '➕'}</button>
              {editCorpId && <button type="button" style={{ ...s.btn, ...s.btnGhost, height: '44px' }} onClick={() => { setEditCorpId(null); setCorpForm({ name: '', vat_no: '', phone: '', address: '' }); }}>✕</button>}
            </div>
          </form>
        </div>

        <div style={s.card}>
          <table style={s.table}>
            <thead>
              <tr>
                <th style={s.th}>Name</th>
                <th style={s.th}>VAT No</th>
                <th style={s.th}>Phone</th>
                <th style={s.th}>Address</th>
                <th style={{ ...s.th, textAlign: 'center' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id}>
                  <td style={{ ...s.td, fontWeight: '600' }}>{c.name}</td>
                  <td style={s.td}>{c.vat_no || '-'}</td>
                  <td style={s.td}>{c.phone || '-'}</td>
                  <td style={s.td}>{c.address || '-'}</td>
                  <td style={s.tdCenter}>
                    <div style={s.actionsCell}>
                      <button style={{ ...s.actionBtn, background: '#065F46', color: '#34D399' }} onClick={() => handleEditCorp(c)}>✏️</button>
                      <button style={{ ...s.actionBtn, background: '#991B1B', color: '#FECACA' }} onClick={() => handleDelete('corporates', c.id)}>🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // ═══ CREDITORS ═══
  if (page === 'creditors') {
    const filtered = (data.creditors || []).filter(c =>
      !searchTerm || c.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>💳 {t('creditors', 'Creditors')}</h1>
          <input style={s.input} placeholder="Search..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>

        <div style={s.card}>
          <h3 style={{ color: '#FBBF24', marginBottom: '15px', marginTop: 0 }}>{editCredId ? '✏️ Edit Creditor' : '➕ Add Creditor'}</h3>
          <form onSubmit={handleAddEditCred} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr auto', gap: '15px', alignItems: 'end' }}>
            <div>
              <label style={s.formLabel}>Name *</label>
              <input style={s.formInput} value={creditorForm?.name || ''} onChange={e => setCreditorForm(prev => ({...prev, name: e.target.value}))} required />
            </div>
            <div>
              <label style={s.formLabel}>Phone</label>
              <input style={s.formInput} value={creditorForm?.phone || ''} onChange={e => setCreditorForm(prev => ({...prev, phone: e.target.value}))} />
            </div>
            <div>
              <label style={s.formLabel}>Address</label>
              <input style={s.formInput} value={creditorForm?.address || ''} onChange={e => setCreditorForm(prev => ({...prev, address: e.target.value}))} />
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button type="submit" style={{ ...s.btn, ...s.btnSuccess, height: '44px' }}>{editCredId ? '💾' : '➕'}</button>
              {editCredId && <button type="button" style={{ ...s.btn, ...s.btnGhost, height: '44px' }} onClick={() => { setEditCredId(null); setCreditorForm({ name: '', phone: '', address: '' }); }}>✕</button>}
            </div>
          </form>
        </div>

        <div style={s.card}>
          <table style={s.table}>
            <thead>
              <tr>
                <th style={s.th}>Name</th>
                <th style={s.th}>Phone</th>
                <th style={s.th}>Address</th>
                <th style={{ ...s.th, textAlign: 'center' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id}>
                  <td style={{ ...s.td, fontWeight: '600' }}>{c.name}</td>
                  <td style={s.td}>{c.phone || '-'}</td>
                  <td style={s.td}>{c.address || '-'}</td>
                  <td style={s.tdCenter}>
                    <div style={s.actionsCell}>
                      <button style={{ ...s.actionBtn, background: '#065F46', color: '#34D399' }} onClick={() => handleEditCred(c)}>✏️</button>
                      <button style={{ ...s.actionBtn, background: '#991B1B', color: '#FECACA' }} onClick={() => handleDelete('creditors', c.id)}>🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // ═══ CREDIT BALANCES ═══
  if (page === 'credit') {
    const withCredit = (data.customers || []).filter(c => (c.store_credit || 0) > 0);
    const totalCredit = withCredit.reduce((s, c) => s + (c.store_credit || 0), 0);

    return (
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>💳 {t('credit', 'Credit Balances')}</h1>
        </div>
        <div style={s.statsGrid}>
          <div style={s.statCard}>
            <div style={s.statLabel}>Customers with Credit</div>
            <div style={s.statValue}>{withCredit.length}</div>
          </div>
          <div style={s.statCard}>
            <div style={s.statLabel}>Total Credit</div>
            <div style={{ ...s.statValue, color: '#A78BFA' }}>{fmt(totalCredit)}</div>
          </div>
        </div>
        <div style={s.card}>
          <table style={s.table}>
            <thead>
              <tr>
                <th style={s.th}>Customer</th>
                <th style={s.th}>Phone</th>
                <th style={{ ...s.th, textAlign: 'right' }}>Credit Balance</th>
                <th style={{ ...s.th, textAlign: 'right' }}>Credit Limit</th>
              </tr>
            </thead>
            <tbody>
              {withCredit.map(c => (
                <tr key={c.id}>
                  <td style={{ ...s.td, fontWeight: '600' }}>{c.name}</td>
                  <td style={s.td}>{c.phone || '-'}</td>
                  <td style={{ ...s.tdRight, color: '#A78BFA', fontWeight: '700' }}>{fmt(c.store_credit)}</td>
                  <td style={s.tdRight}>{fmt(c.credit_limit)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // ═══ MY ATTENDANCE (Placeholder) ═══
  if (page === 'my_attendance') {
    return (
      <div style={s.container}>
        <div style={s.card}>
          <div style={s.emptyState}>
            <div style={s.emptyIcon}>⏰</div>
            <h2 style={{ color: '#FBBF24', marginBottom: '15px' }}>⏰ {t('my_attendance', 'My Attendance')}</h2>
            <p style={{ color: '#94A3B8', maxWidth: '400px', margin: '0 auto', lineHeight: '1.6' }}>
              View your attendance records here. Check-in and check-out times will be displayed here. This feature requires HR module access.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ═══ FALLBACK ═══
  return (
    <div style={s.container}>
      <div style={s.card}>
        <div style={s.emptyState}>
          <div style={s.emptyIcon}>🚧</div>
          <h2 style={{ color: '#FBBF24', marginBottom: '10px' }}>Page Under Development</h2>
          <p style={{ color: '#94A3B8' }}>{page}</p>
          <button style={{ ...s.btn, ...s.btnPrimary, marginTop: '20px' }} onClick={() => setPage('dashboard')}>
            ← Back to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}
